self.__NEXT_FONT_MANIFEST={
  "pages": {
    "/_app": [
      "static/media/a2117d63e64fe351-s.p.woff2"
    ]
  },
  "app": {},
  "appUsingSizeAdjust": false,
  "pagesUsingSizeAdjust": true
}