const CardRight = () => {
  return <div>Card Right</div>;
};

export default CardRight;
